import React from 'react';
import { User } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolBio = () => {
  const tool = mainTools.find(t => t.id === 'bio')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<User className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="bio" />;
};
export default ToolBio;
