import React from 'react';
import { Smartphone } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolWhatsapp = () => {
  const tool = mainTools.find(t => t.id === 'whatsapp')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Smartphone className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="whatsapp" />;
};
export default ToolWhatsapp;
