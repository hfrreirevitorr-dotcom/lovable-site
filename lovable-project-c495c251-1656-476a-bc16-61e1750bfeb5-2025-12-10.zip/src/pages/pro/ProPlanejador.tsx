import React from 'react';
import { Calendar } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProPlanejador = () => {
  const tool = proTools.find(t => t.id === 'planejador')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Calendar className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="planejador" />;
};
export default ProPlanejador;
