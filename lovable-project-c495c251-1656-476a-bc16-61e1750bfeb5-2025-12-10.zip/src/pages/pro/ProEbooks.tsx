import React from 'react';
import { BookOpen } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProEbooks = () => {
  const tool = proTools.find(t => t.id === 'ebooks')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<BookOpen className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="ebooks" />;
};
export default ProEbooks;
