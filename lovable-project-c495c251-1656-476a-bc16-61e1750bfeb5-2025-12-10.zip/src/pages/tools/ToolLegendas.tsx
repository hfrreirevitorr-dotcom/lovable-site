import React from 'react';
import { Type } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolLegendas = () => {
  const tool = mainTools.find(t => t.id === 'legendas')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Type className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="legendas" />;
};
export default ToolLegendas;
