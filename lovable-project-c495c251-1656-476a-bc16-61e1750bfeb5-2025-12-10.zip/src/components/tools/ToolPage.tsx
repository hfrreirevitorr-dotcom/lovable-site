import React, { useState } from 'react';
import { ArrowLeft, Sparkles, Wand2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ResultCard from '@/components/common/ResultCard';
import SkeletonCard from '@/components/common/SkeletonCard';
import { businessTypes } from '@/data/tools';
import { useContentGeneration } from '@/hooks/useContentGeneration';

interface ToolPageProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  prompt: string;
  toolType: string;
}

const ToolPage: React.FC<ToolPageProps> = ({
  title,
  description,
  icon,
  toolType,
}) => {
  const [businessType, setBusinessType] = useState('');
  const [customBusiness, setCustomBusiness] = useState('');
  const { results, isLoading, generate } = useContentGeneration();

  const selectedBusiness = customBusiness || businessType;

  const handleGenerate = () => {
    if (selectedBusiness) {
      generate(toolType, selectedBusiness);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4 group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Voltar ao Dashboard
        </Link>

        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg shadow-primary/20">
            {icon}
          </div>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold font-display text-foreground">
              {title}
            </h1>
            <p className="text-muted-foreground">{description}</p>
          </div>
        </div>
      </div>

      {/* Input Section */}
      <div className="glass-card rounded-xl p-6 mb-8 border border-border/50">
        <div className="flex items-center gap-2 mb-4">
          <Wand2 className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">Selecione o tipo de negócio</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mb-4">
          {businessTypes.map((type) => (
            <button
              key={type}
              onClick={() => {
                setBusinessType(type);
                setCustomBusiness('');
              }}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                businessType === type && !customBusiness
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                  : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        <div className="relative mb-6">
          <p className="text-sm text-muted-foreground mb-2">
            Ou digite seu tipo de negócio:
          </p>
          <Input
            value={customBusiness}
            onChange={(e) => {
              setCustomBusiness(e.target.value);
              setBusinessType('');
            }}
            placeholder="Ex: Loja de artesanato, Consultoria financeira..."
            className="bg-input"
          />
        </div>

        <Button
          variant="neon"
          size="xl"
          onClick={handleGenerate}
          disabled={!selectedBusiness || isLoading}
          className="w-full"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Gerando com IA...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Gerar Conteúdo com IA
            </>
          )}
        </Button>

        {selectedBusiness && (
          <p className="text-xs text-center text-muted-foreground mt-3">
            Tipo selecionado: <span className="text-primary font-medium">{selectedBusiness}</span>
          </p>
        )}
      </div>

      {/* Loading Skeletons */}
      {isLoading && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold font-display flex items-center gap-2">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            Gerando resultados...
          </h2>
          <div className="grid gap-4">
            {[0, 1, 2].map((i) => (
              <SkeletonCard key={i} index={i} />
            ))}
          </div>
        </div>
      )}

      {/* Results Section */}
      {!isLoading && results.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold font-display flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Resultados Gerados
            <span className="text-sm font-normal text-muted-foreground">
              ({results.length} resultado{results.length > 1 ? 's' : ''})
            </span>
          </h2>
          <div className="grid gap-4">
            {results.map((result, index) => (
              <ResultCard
                key={index}
                content={result}
                type={toolType}
                businessType={selectedBusiness}
                index={index}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ToolPage;
