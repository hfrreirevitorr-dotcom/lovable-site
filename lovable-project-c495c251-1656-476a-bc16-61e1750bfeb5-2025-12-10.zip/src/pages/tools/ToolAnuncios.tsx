import React from 'react';
import { Megaphone } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolAnuncios = () => {
  const tool = mainTools.find(t => t.id === 'anuncios')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Megaphone className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="anuncios" />;
};
export default ToolAnuncios;
