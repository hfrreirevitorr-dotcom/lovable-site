import React from 'react';
import { Percent } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolPromocoes = () => {
  const tool = mainTools.find(t => t.id === 'promocoes')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Percent className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="promocoes" />;
};
export default ToolPromocoes;
