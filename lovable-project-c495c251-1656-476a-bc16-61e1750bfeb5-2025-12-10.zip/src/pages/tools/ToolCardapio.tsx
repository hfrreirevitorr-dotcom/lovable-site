import React from 'react';
import { Utensils } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolCardapio = () => {
  const tool = mainTools.find(t => t.id === 'cardapio')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Utensils className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="cardapio" />;
};
export default ToolCardapio;
