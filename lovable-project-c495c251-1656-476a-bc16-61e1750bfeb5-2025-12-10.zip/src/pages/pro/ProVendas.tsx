import React from 'react';
import { TrendingUp } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProVendas = () => {
  const tool = proTools.find(t => t.id === 'vendas')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<TrendingUp className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="vendas" />;
};
export default ProVendas;
