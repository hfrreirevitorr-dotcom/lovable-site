import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Crown,
  Check,
  ArrowLeft,
  Zap,
  Globe,
  Layout,
  ShoppingCart,
  BookOpen,
  TrendingUp,
  Calendar,
  Lock,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import ToolCard from '@/components/common/ToolCard';
import { proTools } from '@/data/tools';
import { useUser } from '@/contexts/UserContext';
import { toast } from 'sonner';

const Pro: React.FC = () => {
  const { user, isLoggedIn, upgradeToPro } = useUser();
  const navigate = useNavigate();
  const [showPayment, setShowPayment] = useState(false);

  const benefits = [
    'Remover todos os limites',
    'Gerar conteúdos ilimitados',
    'Criar sites automáticos',
    'Salvar mais resultados',
    'Respostas mais longas e detalhadas',
    'Acesso a 6 ferramentas exclusivas',
    'Suporte prioritário',
    'Atualizações antecipadas',
  ];

  const handleActivatePro = () => {
    if (!isLoggedIn) {
      toast.error('Faça login para ativar o PRO');
      navigate('/auth');
      return;
    }
    setShowPayment(true);
  };

  const handleConfirmPayment = () => {
    upgradeToPro();
    setShowPayment(false);
    toast.success('🎉 Parabéns! Seu plano PRO foi ativado!');
  };

  if (showPayment) {
    return (
      <div className="max-w-lg mx-auto py-12">
        <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/5 to-orange-500/5">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                <Crown className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold font-display text-foreground">
                Ativar Mitologico PRO
              </h2>
              <p className="text-muted-foreground mt-2">
                Desbloqueie todo o potencial da plataforma
              </p>
            </div>

            <div className="bg-muted/50 rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-medium">Plano Mensal</span>
                <div className="text-right">
                  <span className="text-3xl font-bold text-foreground">R$ 47</span>
                  <span className="text-muted-foreground">/mês</span>
                </div>
              </div>
              <ul className="space-y-2">
                {benefits.slice(0, 4).map((benefit) => (
                  <li key={benefit} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-500" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <Button
                variant="pro"
                size="xl"
                className="w-full"
                onClick={handleConfirmPayment}
              >
                <Sparkles className="w-5 h-5" />
                Confirmar Pagamento (Simulado)
              </Button>
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => setShowPayment(false)}
              >
                Voltar
              </Button>
            </div>

            <p className="text-xs text-center text-muted-foreground mt-4">
              💡 Esta é uma simulação. Nenhum pagamento real será processado.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Link>
      </div>

      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-card p-8 lg:p-12 text-center">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="relative z-10">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center animate-pulse-neon">
            <Crown className="w-12 h-12 text-white" />
          </div>

          <h1 className="text-4xl lg:text-5xl font-bold font-display mb-4">
            <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Mitologico PRO
            </span>
          </h1>

          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Desbloqueie todo o potencial da plataforma com ferramentas exclusivas 
            e recursos ilimitados para fazer seu negócio decolar.
          </p>

          {user?.isPro ? (
            <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold text-lg">
              <Check className="w-6 h-6" />
              Você já é PRO!
            </div>
          ) : (
            <Button variant="pro" size="xl" onClick={handleActivatePro}>
              <Zap className="w-6 h-6" />
              Ativar PRO Agora
            </Button>
          )}
        </div>
      </section>

      {/* Benefits */}
      <section>
        <h2 className="text-2xl font-bold font-display text-center mb-8">
          Benefícios Exclusivos
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {benefits.map((benefit, index) => (
            <div
              key={benefit}
              className="glass-card rounded-xl p-5 opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0">
                  <Check className="w-5 h-5 text-white" />
                </div>
                <span className="text-foreground font-medium">{benefit}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pro Tools */}
      <section>
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold font-display text-foreground mb-2">
            Ferramentas PRO Exclusivas
          </h2>
          <p className="text-muted-foreground">
            {user?.isPro
              ? 'Acesse todas as ferramentas exclusivas abaixo'
              : 'Ative o PRO para desbloquear estas ferramentas'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {proTools.map((tool, index) => (
            <div key={tool.id} className="relative">
              {!user?.isPro && (
                <div className="absolute inset-0 z-10 bg-background/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <div className="text-center p-4">
                    <Lock className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                    <p className="text-sm font-medium text-foreground">Exclusivo PRO</p>
                  </div>
                </div>
              )}
              <ToolCard tool={tool} index={index} />
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      {!user?.isPro && (
        <section className="text-center py-12">
          <h2 className="text-3xl font-bold font-display text-foreground mb-4">
            Pronto para decolar?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Junte-se a milhares de empreendedores que já estão usando o Mitologico PRO 
            para criar conteúdo profissional e aumentar suas vendas.
          </p>
          <Button variant="pro" size="xl" onClick={handleActivatePro}>
            <Crown className="w-6 h-6" />
            Ativar PRO por R$ 47/mês
          </Button>
        </section>
      )}
    </div>
  );
};

export default Pro;
