import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, ArrowLeft, Trash2, Copy, Check, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/contexts/UserContext';
import { toast } from 'sonner';

const Favorites: React.FC = () => {
  const { savedContents, toggleFavorite, deleteContent, isLoggedIn } = useUser();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  React.useEffect(() => {
    if (!isLoggedIn) {
      navigate('/auth');
    }
  }, [isLoggedIn, navigate]);

  const favorites = savedContents.filter((c) => c.isFavorite);
  const allSaved = savedContents;

  const displayedContents = filter === 'favorites' ? favorites : allSaved;
  
  const contentTypes = [...new Set(savedContents.map((c) => c.type))];

  const filteredContents = filter === 'all' || filter === 'favorites'
    ? displayedContents
    : displayedContents.filter((c) => c.type === filter);

  const handleCopy = async (content: string, id: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast.success('Texto copiado!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = (id: string) => {
    deleteContent(id);
    toast.success('Conteúdo removido');
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      posts: 'Post',
      legendas: 'Legenda',
      promocoes: 'Promoção',
      anuncios: 'Anúncio',
      chat: 'Chat',
      whatsapp: 'WhatsApp',
      produtos: 'Produto',
      cardapio: 'Cardápio',
      bio: 'Bio',
      campanhas: 'Campanha',
      analisador: 'Análise',
      sites: 'Site',
      landing: 'Landing',
      loja: 'Loja',
      ebooks: 'Ebook',
      vendas: 'Vendas',
      planejador: 'Planejador',
    };
    return labels[type] || type;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground flex items-center gap-3">
            <Heart className="w-8 h-8 text-accent" />
            Favoritos & Salvos
          </h1>
          <p className="text-muted-foreground mt-1">
            {savedContents.length} conteúdo(s) salvo(s) • {favorites.length} favorito(s)
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={filter === 'all' ? 'neon' : 'ghost'}
          size="sm"
          onClick={() => setFilter('all')}
        >
          <Filter className="w-4 h-4" />
          Todos
        </Button>
        <Button
          variant={filter === 'favorites' ? 'neon-pink' : 'ghost'}
          size="sm"
          onClick={() => setFilter('favorites')}
        >
          <Heart className="w-4 h-4" />
          Favoritos
        </Button>
        {contentTypes.map((type) => (
          <Button
            key={type}
            variant={filter === type ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => setFilter(type)}
          >
            {getTypeLabel(type)}
          </Button>
        ))}
      </div>

      {/* Content List */}
      {filteredContents.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">
            Nenhum conteúdo encontrado
          </h3>
          <p className="text-muted-foreground mb-6">
            {filter === 'favorites'
              ? 'Você ainda não favoritou nenhum conteúdo.'
              : 'Comece gerando conteúdo com nossas ferramentas!'}
          </p>
          <Link to="/">
            <Button variant="neon">Ir para as Ferramentas</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredContents.map((content, index) => (
            <div
              key={content.id}
              className="result-card rounded-xl p-5 opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${index * 50}ms`, animationFillMode: 'forwards' }}
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 text-xs font-semibold bg-primary/20 text-primary rounded-full">
                    {getTypeLabel(content.type)}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {content.businessType}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => toggleFavorite(content.id)}
                    className={`p-2 rounded-lg transition-colors ${
                      content.isFavorite
                        ? 'text-accent bg-accent/10'
                        : 'text-muted-foreground hover:text-accent hover:bg-accent/10'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${content.isFavorite ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => handleDelete(content.id)}
                    className="p-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <p className="text-foreground whitespace-pre-wrap leading-relaxed mb-4 line-clamp-4">
                {content.content}
              </p>

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <span className="text-xs text-muted-foreground">
                  {new Date(content.createdAt).toLocaleDateString('pt-BR')}
                </span>
                <Button
                  variant="neon-outline"
                  size="sm"
                  onClick={() => handleCopy(content.content, content.id)}
                >
                  {copiedId === content.id ? (
                    <>
                      <Check className="w-4 h-4" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copiar
                    </>
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Favorites;
