import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Calendar, Crown, Trash2, Heart, FileText, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUser } from '@/contexts/UserContext';
import { toast } from 'sonner';

const Account: React.FC = () => {
  const { user, savedContents, clearAllContent, upgradeToPro, isLoggedIn } = useUser();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (!isLoggedIn) {
      navigate('/auth');
    }
  }, [isLoggedIn, navigate]);

  if (!user) return null;

  const favoriteCount = savedContents.filter((c) => c.isFavorite).length;
  const createdAt = new Date(user.createdAt).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  const handleClearAll = () => {
    if (window.confirm('Tem certeza que deseja excluir todos os conteúdos salvos?')) {
      clearAllContent();
      toast.success('Todos os conteúdos foram excluídos');
    }
  };

  const handleUpgrade = () => {
    navigate('/pro');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Link>
      </div>

      <h1 className="text-3xl font-bold font-display text-foreground">Minha Conta</h1>

      {/* User Profile Card */}
      <Card className="border-border">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            Perfil
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <span className="text-3xl font-bold text-primary-foreground">
                {user.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">{user.name}</h2>
              <p className="text-muted-foreground">{user.email}</p>
              <div className="flex items-center gap-2 mt-2">
                {user.isPro ? (
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-500 text-sm font-bold flex items-center gap-1">
                    <Crown className="w-4 h-4" />
                    Plano PRO
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-sm font-medium">
                    Plano Gratuito
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-border">
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <Calendar className="w-5 h-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Membro desde</p>
                <p className="font-medium text-foreground">{createdAt}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <FileText className="w-5 h-5 text-secondary" />
              <div>
                <p className="text-sm text-muted-foreground">Conteúdos salvos</p>
                <p className="font-medium text-foreground">{savedContents.length}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <Heart className="w-5 h-5 text-accent" />
              <div>
                <p className="text-sm text-muted-foreground">Favoritos</p>
                <p className="font-medium text-foreground">{favoriteCount}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {!user.isPro && (
          <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/10 to-orange-500/10">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-1">Ativar PRO</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Desbloqueie todas as ferramentas e recursos exclusivos
                  </p>
                  <Button variant="pro" onClick={handleUpgrade}>
                    Conhecer Plano PRO
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-destructive/30">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-destructive/20 flex items-center justify-center">
                <Trash2 className="w-6 h-6 text-destructive" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold text-foreground mb-1">Excluir Dados</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Remover todos os conteúdos salvos e favoritos
                </p>
                <Button
                  variant="outline"
                  className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                  onClick={handleClearAll}
                  disabled={savedContents.length === 0}
                >
                  Excluir Tudo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Links */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Acesso Rápido</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Link
              to="/favoritos"
              className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <Heart className="w-6 h-6 text-accent" />
              <span className="text-sm font-medium">Favoritos</span>
            </Link>
            <Link
              to="/tools/posts"
              className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <FileText className="w-6 h-6 text-primary" />
              <span className="text-sm font-medium">Gerar Posts</span>
            </Link>
            <Link
              to="/pro"
              className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <Crown className="w-6 h-6 text-amber-500" />
              <span className="text-sm font-medium">Área PRO</span>
            </Link>
            <Link
              to="/"
              className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-secondary" />
              <span className="text-sm font-medium">Dashboard</span>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Account;
