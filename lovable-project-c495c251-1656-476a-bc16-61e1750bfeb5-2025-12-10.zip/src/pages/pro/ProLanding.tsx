import React from 'react';
import { Layout } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProLanding = () => {
  const tool = proTools.find(t => t.id === 'landing')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Layout className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="landing" />;
};
export default ProLanding;
