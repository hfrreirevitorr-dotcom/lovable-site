import React from 'react';
import { Globe } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProSites = () => {
  const tool = proTools.find(t => t.id === 'sites')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Globe className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="sites" />;
};
export default ProSites;
