import React from 'react';
import { BarChart2 } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolAnalisador = () => {
  const tool = mainTools.find(t => t.id === 'analisador')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<BarChart2 className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="analisador" />;
};
export default ToolAnalisador;
