import React from 'react';
import { Link } from 'react-router-dom';
import { Crown, Sparkles, Zap, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ToolCard from '@/components/common/ToolCard';
import { mainTools } from '@/data/tools';
import { useUser } from '@/contexts/UserContext';

const Index: React.FC = () => {
  const { user, isLoggedIn } = useUser();

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-card to-secondary/20 p-8 lg:p-12">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-neon">
              <Crown className="w-7 h-7 text-primary-foreground" />
            </div>
            <div className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-semibold">
              Suite Completa
            </div>
          </div>

          <h1 className="text-3xl lg:text-5xl font-bold font-display mb-4">
            <span className="gradient-text">Mitologico Business Suite</span>
            <span className="text-primary"> PRO</span>
          </h1>

          <p className="text-lg lg:text-xl text-muted-foreground mb-6 max-w-2xl">
            A plataforma definitiva para donos de pequenos negócios criarem conteúdo, 
            anúncios, scripts de atendimento e automações com inteligência artificial.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            {!isLoggedIn ? (
              <>
                <Link to="/auth">
                  <Button variant="neon" size="xl">
                    <Sparkles className="w-5 h-5" />
                    Começar Grátis
                  </Button>
                </Link>
                <Link to="/pro">
                  <Button variant="pro" size="xl">
                    <Crown className="w-5 h-5" />
                    Conhecer PRO
                  </Button>
                </Link>
              </>
            ) : (
              <div className="flex items-center gap-4">
                <div className="text-lg">
                  Olá, <span className="font-bold text-primary">{user?.name}</span>! 👋
                </div>
                {!user?.isPro && (
                  <Link to="/pro">
                    <Button variant="pro" size="lg">
                      <Crown className="w-5 h-5" />
                      Ativar PRO
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-4 right-4 w-32 h-32 bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-4 right-24 w-24 h-24 bg-secondary/20 rounded-full blur-2xl" />
        <div className="absolute top-1/2 right-12 w-16 h-16 bg-accent/20 rounded-full blur-xl" />
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Zap, label: 'Ferramentas', value: '12+', color: 'from-primary to-secondary' },
          { icon: Sparkles, label: 'Conteúdos Gerados', value: '∞', color: 'from-secondary to-primary' },
          { icon: TrendingUp, label: 'Tipos de Negócio', value: '20+', color: 'from-accent to-primary' },
          { icon: Crown, label: 'Recursos PRO', value: '6', color: 'from-amber-500 to-orange-500' },
        ].map((stat, index) => (
          <div
            key={stat.label}
            className="glass-card rounded-xl p-4 lg:p-6 opacity-0 animate-fade-in-up"
            style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
          >
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <p className="text-2xl lg:text-3xl font-bold font-display text-foreground">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </section>

      {/* Tools Grid */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold font-display text-foreground">Ferramentas</h2>
            <p className="text-muted-foreground">Escolha uma ferramenta para começar a criar</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {mainTools.map((tool, index) => (
            <ToolCard key={tool.id} tool={tool} index={index} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Index;
