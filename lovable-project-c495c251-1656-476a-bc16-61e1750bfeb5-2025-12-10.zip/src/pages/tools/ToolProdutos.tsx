import React from 'react';
import { Package } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolProdutos = () => {
  const tool = mainTools.find(t => t.id === 'produtos')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Package className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="produtos" />;
};
export default ToolProdutos;
