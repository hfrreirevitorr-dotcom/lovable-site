import React from 'react';
import { Target } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolCampanhas = () => {
  const tool = mainTools.find(t => t.id === 'campanhas')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Target className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="campanhas" />;
};
export default ToolCampanhas;
