import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { UserProvider } from "@/contexts/UserContext";
import MainLayout from "@/components/layout/MainLayout";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Account from "./pages/Account";
import Favorites from "./pages/Favorites";
import Pro from "./pages/Pro";
import ToolPosts from "./pages/tools/ToolPosts";
import ToolLegendas from "./pages/tools/ToolLegendas";
import ToolPromocoes from "./pages/tools/ToolPromocoes";
import ToolAnuncios from "./pages/tools/ToolAnuncios";
import ToolChat from "./pages/tools/ToolChat";
import ToolWhatsapp from "./pages/tools/ToolWhatsapp";
import ToolProdutos from "./pages/tools/ToolProdutos";
import ToolCardapio from "./pages/tools/ToolCardapio";
import ToolBio from "./pages/tools/ToolBio";
import ToolCampanhas from "./pages/tools/ToolCampanhas";
import ToolAnalisador from "./pages/tools/ToolAnalisador";
import ProSites from "./pages/pro/ProSites";
import ProLanding from "./pages/pro/ProLanding";
import ProLoja from "./pages/pro/ProLoja";
import ProEbooks from "./pages/pro/ProEbooks";
import ProVendas from "./pages/pro/ProVendas";
import ProPlanejador from "./pages/pro/ProPlanejador";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <UserProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route element={<MainLayout />}>
              <Route path="/" element={<Index />} />
              <Route path="/conta" element={<Account />} />
              <Route path="/favoritos" element={<Favorites />} />
              <Route path="/pro" element={<Pro />} />
              <Route path="/tools/posts" element={<ToolPosts />} />
              <Route path="/tools/legendas" element={<ToolLegendas />} />
              <Route path="/tools/promocoes" element={<ToolPromocoes />} />
              <Route path="/tools/anuncios" element={<ToolAnuncios />} />
              <Route path="/tools/chat" element={<ToolChat />} />
              <Route path="/tools/whatsapp" element={<ToolWhatsapp />} />
              <Route path="/tools/produtos" element={<ToolProdutos />} />
              <Route path="/tools/cardapio" element={<ToolCardapio />} />
              <Route path="/tools/bio" element={<ToolBio />} />
              <Route path="/tools/campanhas" element={<ToolCampanhas />} />
              <Route path="/tools/analisador" element={<ToolAnalisador />} />
              <Route path="/pro/sites" element={<ProSites />} />
              <Route path="/pro/landing" element={<ProLanding />} />
              <Route path="/pro/loja" element={<ProLoja />} />
              <Route path="/pro/ebooks" element={<ProEbooks />} />
              <Route path="/pro/vendas" element={<ProVendas />} />
              <Route path="/pro/planejador" element={<ProPlanejador />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </UserProvider>
  </QueryClientProvider>
);

export default App;
