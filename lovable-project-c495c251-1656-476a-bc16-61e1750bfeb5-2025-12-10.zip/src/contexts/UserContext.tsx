import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, SavedContent } from '@/types';

interface UserContextType {
  user: User | null;
  isLoggedIn: boolean;
  savedContents: SavedContent[];
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  saveContent: (content: Omit<SavedContent, 'id' | 'createdAt'>) => void;
  toggleFavorite: (id: string) => void;
  deleteContent: (id: string) => void;
  clearAllContent: () => void;
  upgradeToPro: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [savedContents, setSavedContents] = useState<SavedContent[]>([]);

  useEffect(() => {
    const storedUser = localStorage.getItem('mitologico_user');
    const storedContents = localStorage.getItem('mitologico_contents');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    if (storedContents) {
      setSavedContents(JSON.parse(storedContents));
    }
  }, []);

  useEffect(() => {
    if (user) {
      localStorage.setItem('mitologico_user', JSON.stringify(user));
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('mitologico_contents', JSON.stringify(savedContents));
  }, [savedContents]);

  const login = (email: string, password: string): boolean => {
    const storedUsers = JSON.parse(localStorage.getItem('mitologico_users') || '[]');
    const foundUser = storedUsers.find((u: User & { password: string }) => 
      u.email === email && u.password === password
    );
    
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      return true;
    }
    return false;
  };

  const signup = (name: string, email: string, password: string): boolean => {
    const storedUsers = JSON.parse(localStorage.getItem('mitologico_users') || '[]');
    
    if (storedUsers.some((u: User) => u.email === email)) {
      return false;
    }

    const newUser: User & { password: string } = {
      id: crypto.randomUUID(),
      name,
      email,
      password,
      isPro: false,
      createdAt: new Date().toISOString(),
    };

    storedUsers.push(newUser);
    localStorage.setItem('mitologico_users', JSON.stringify(storedUsers));
    
    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('mitologico_user');
  };

  const saveContent = (content: Omit<SavedContent, 'id' | 'createdAt'>) => {
    const newContent: SavedContent = {
      ...content,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setSavedContents(prev => [newContent, ...prev]);
  };

  const toggleFavorite = (id: string) => {
    setSavedContents(prev =>
      prev.map(item =>
        item.id === id ? { ...item, isFavorite: !item.isFavorite } : item
      )
    );
  };

  const deleteContent = (id: string) => {
    setSavedContents(prev => prev.filter(item => item.id !== id));
  };

  const clearAllContent = () => {
    setSavedContents([]);
  };

  const upgradeToPro = () => {
    if (user) {
      const updatedUser = { ...user, isPro: true };
      setUser(updatedUser);
      
      const storedUsers = JSON.parse(localStorage.getItem('mitologico_users') || '[]');
      const updatedUsers = storedUsers.map((u: User) =>
        u.id === user.id ? { ...u, isPro: true } : u
      );
      localStorage.setItem('mitologico_users', JSON.stringify(updatedUsers));
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        savedContents,
        login,
        signup,
        logout,
        saveContent,
        toggleFavorite,
        deleteContent,
        clearAllContent,
        upgradeToPro,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
