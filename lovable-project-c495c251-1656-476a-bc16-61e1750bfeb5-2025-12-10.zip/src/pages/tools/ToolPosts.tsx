import React from 'react';
import { Image } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { mainTools } from '@/data/tools';

const ToolPosts = () => {
  const tool = mainTools.find(t => t.id === 'posts')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<Image className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="posts" />;
};
export default ToolPosts;
