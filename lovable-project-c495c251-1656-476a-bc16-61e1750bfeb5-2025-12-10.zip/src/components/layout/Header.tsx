import React from 'react';
import { Link } from 'react-router-dom';
import { Menu, Crown, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/contexts/UserContext';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const { user, isLoggedIn } = useUser();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 lg:px-6 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="p-2 hover:bg-muted rounded-lg transition-colors lg:hidden"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="hidden lg:flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Crown className="w-5 h-5 text-primary-foreground" />
          </div>
          <h1 className="font-display text-lg font-bold gradient-text">
            Mitologico Business Suite PRO
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {isLoggedIn ? (
          <>
            <button className="p-2 hover:bg-muted rounded-lg transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full" />
            </button>

            {!user?.isPro && (
              <Link to="/pro">
                <Button variant="pro" size="sm" className="hidden sm:flex">
                  <Crown className="w-4 h-4" />
                  Ativar PRO
                </Button>
              </Link>
            )}

            <Link to="/conta" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-sm font-bold text-primary-foreground">
                  {user?.name.charAt(0).toUpperCase()}
                </span>
              </div>
            </Link>
          </>
        ) : (
          <Link to="/auth">
            <Button variant="neon">
              Entrar
            </Button>
          </Link>
        )}
      </div>
    </header>
  );
};

export default Header;
