import React from 'react';
import { Link } from 'react-router-dom';
import { Crown, ArrowRight } from 'lucide-react';
import { Tool } from '@/types';
import {
  Image,
  Type,
  Percent,
  Megaphone,
  MessageCircle,
  Smartphone,
  Package,
  Utensils,
  User,
  Target,
  BarChart2,
  Globe,
  Layout,
  ShoppingCart,
  BookOpen,
  TrendingUp,
  Calendar,
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  image: Image,
  type: Type,
  percent: Percent,
  megaphone: Megaphone,
  'message-circle': MessageCircle,
  smartphone: Smartphone,
  package: Package,
  utensils: Utensils,
  user: User,
  target: Target,
  'bar-chart-2': BarChart2,
  crown: Crown,
  globe: Globe,
  layout: Layout,
  'shopping-cart': ShoppingCart,
  'book-open': BookOpen,
  'trending-up': TrendingUp,
  calendar: Calendar,
};

interface ToolCardProps {
  tool: Tool;
  index: number;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool, index }) => {
  const IconComponent = iconMap[tool.icon] || Package;

  return (
    <Link
      to={tool.path}
      className="tool-card group block rounded-xl p-6 opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={`w-12 h-12 rounded-xl flex items-center justify-center ${
            tool.isPro
              ? 'bg-gradient-to-br from-amber-500 to-orange-500'
              : 'bg-gradient-to-br from-primary to-secondary'
          }`}
        >
          <IconComponent className="w-6 h-6 text-white" />
        </div>
        {tool.isPro && (
          <span className="px-2 py-1 text-xs font-bold bg-amber-500/20 text-amber-500 rounded-full flex items-center gap-1">
            <Crown className="w-3 h-3" />
            PRO
          </span>
        )}
      </div>

      <h3 className="text-lg font-bold font-display text-foreground mb-2 group-hover:text-primary transition-colors">
        {tool.name}
      </h3>
      <p className="text-sm text-muted-foreground mb-4">{tool.description}</p>

      <div className="flex items-center text-sm font-medium text-primary group-hover:gap-2 transition-all">
        Acessar
        <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
      </div>
    </Link>
  );
};

export default ToolCard;
