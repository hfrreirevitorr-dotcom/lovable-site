export interface User {
  id: string;
  name: string;
  email: string;
  isPro: boolean;
  createdAt: string;
}

export interface SavedContent {
  id: string;
  type: string;
  content: string;
  businessType: string;
  createdAt: string;
  isFavorite: boolean;
}

export interface Tool {
  id: string;
  name: string;
  description: string;
  icon: string;
  path: string;
  isPro?: boolean;
  prompt: string;
}
