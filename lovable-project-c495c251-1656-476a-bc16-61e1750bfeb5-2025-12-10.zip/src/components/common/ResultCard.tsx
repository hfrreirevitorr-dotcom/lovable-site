import React, { useState } from 'react';
import { Copy, Heart, Save, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/contexts/UserContext';
import { toast } from 'sonner';

interface ResultCardProps {
  content: string;
  type: string;
  businessType: string;
  index: number;
}

const ResultCard: React.FC<ResultCardProps> = ({ content, type, businessType, index }) => {
  const { isLoggedIn, saveContent, savedContents, toggleFavorite } = useUser();
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const existingContent = savedContents.find(
    (item) => item.content === content && item.type === type
  );
  const isFavorite = existingContent?.isFavorite || false;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    toast.success('Texto copiado!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!isLoggedIn) {
      toast.error('Faça login para salvar conteúdo');
      return;
    }
    saveContent({
      content,
      type,
      businessType,
      isFavorite: false,
    });
    setSaved(true);
    toast.success('Conteúdo salvo!');
  };

  const handleFavorite = () => {
    if (!isLoggedIn) {
      toast.error('Faça login para favoritar');
      return;
    }
    if (existingContent) {
      toggleFavorite(existingContent.id);
      toast.success(isFavorite ? 'Removido dos favoritos' : 'Adicionado aos favoritos');
    } else {
      saveContent({
        content,
        type,
        businessType,
        isFavorite: true,
      });
      toast.success('Adicionado aos favoritos');
    }
  };

  return (
    <div
      className="result-card rounded-xl p-5 animate-fade-in-up opacity-0"
      style={{ animationDelay: `${index * 150}ms`, animationFillMode: 'forwards' }}
    >
      <div className="flex items-start justify-between gap-4 mb-4">
        <span className="px-3 py-1 text-xs font-semibold bg-primary/20 text-primary rounded-full">
          Resultado {index + 1}
        </span>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleFavorite}
            className={isFavorite ? 'text-accent' : 'text-muted-foreground hover:text-accent'}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="prose prose-invert max-w-none mb-4">
        <p className="text-foreground whitespace-pre-wrap leading-relaxed">{content}</p>
      </div>

      <div className="flex items-center gap-2 pt-4 border-t border-border">
        <Button
          variant="neon-outline"
          size="sm"
          onClick={handleCopy}
          className="flex-1"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copiado!' : 'Copiar'}
        </Button>
        <Button
          variant="glass"
          size="sm"
          onClick={handleSave}
          disabled={saved || !!existingContent}
          className="flex-1"
        >
          <Save className="w-4 h-4" />
          {saved || existingContent ? 'Salvo' : 'Salvar'}
        </Button>
      </div>
    </div>
  );
};

export default ResultCard;
