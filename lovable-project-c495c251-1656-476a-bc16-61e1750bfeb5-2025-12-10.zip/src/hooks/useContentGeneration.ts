import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface UseContentGenerationReturn {
  results: string[];
  isLoading: boolean;
  error: string | null;
  generate: (toolType: string, businessType: string) => Promise<void>;
  clearResults: () => void;
}

export const useContentGeneration = (): UseContentGenerationReturn => {
  const [results, setResults] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generate = async (toolType: string, businessType: string) => {
    if (!businessType.trim()) {
      toast.error('Por favor, informe o tipo de negócio');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResults([]);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('generate-content', {
        body: { toolType, businessType },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Erro ao gerar conteúdo');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      if (data?.results && Array.isArray(data.results)) {
        setResults(data.results);
        toast.success(`${data.results.length} resultado(s) gerado(s) com IA!`);
      } else {
        throw new Error('Resposta inválida do servidor');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(message);
      toast.error(message);
      console.error('Content generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const clearResults = () => {
    setResults([]);
    setError(null);
  };

  return { results, isLoading, error, generate, clearResults };
};
