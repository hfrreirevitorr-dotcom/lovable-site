import React from 'react';
import { ShoppingCart } from 'lucide-react';
import ToolPage from '@/components/tools/ToolPage';
import { proTools } from '@/data/tools';

const ProLoja = () => {
  const tool = proTools.find(t => t.id === 'loja')!;
  return <ToolPage title={tool.name} description={tool.description} icon={<ShoppingCart className="w-7 h-7 text-white" />} prompt={tool.prompt} toolType="loja" />;
};
export default ProLoja;
